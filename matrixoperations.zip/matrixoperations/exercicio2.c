/*Este programa tem como objetivo ler do ficheiro DadosVetoresCRS.txt
 * o número de linhas, o número de colunas e o número de elementos não nulos
 *  de uma matriz e os vetores Ax Ac e Ap e obter a matriz na forma densa , 
 * escrvendo-a no ficheiro ResultadosMatrizDensa.txt
  Este programa foi escrito por mim, André Abreu Couto,
  *  cujo número de estudante é 2019215056.
 */


#include <stdio.h>
#include <stdlib.h>

const int D= 10000; /*dimensão da matriz*/
const int L= 100;	/*número de linhas*/
const int C= 100;	/*número de colunas*/
/*subprogramas utilizados*/
void lerVetor(int *dimlA, int *dimcA, int *nz, float Ax[D], int Ac[D], int Ap[D]);
void escreverVetor(int dimlA, int dimcA, int nz, float Ax[D], int Ac[D], int Ap[D]);
void construirMatriz(int dimlA, int dimcA, int nz, float Ax[D], int Ac[D], int Ap[D], float A[L][C]);


/*Programa Principal*/
int main(int argc, char **argv)
{
	int dimlA, dimcA, nz;
	float Ax[D], A[L][C];
	int Ac[D], Ap[D];

	
	lerVetor( &dimlA, &dimcA, &nz, Ax, Ac, Ap);
	escreverVetor(dimlA, dimcA, nz, Ax, Ac, Ap);
	construirMatriz(dimlA, dimcA, nz, Ax, Ac, Ap, A);
	/*imprimir a matriz*/
	printf("\n A matriz densa e: \n");
	int i, j;
	for(i=0; i<dimlA; i++)
	{
		for(j=0; j<dimcA; j++)
		printf(" %0.1f", A[i][j]);
		printf("\n");
	}
	 /*escrever a matriz no ficheiro ResultadosMatrizDensa.txt*/
	 
	FILE *fout;
	
	fout = fopen("ResultadoMatrizDensa.txt", "w");
	fprintf(fout,"\nA Matriz e:\n");
	for(i=0; i<dimlA; i++)
	{
		for(j=0; j<dimcA; j++) 
		fprintf(fout, "%0.1f\t", A[i][j]);
		fprintf(fout, "\n");}
		
	fclose(fout);
	return 0;
}
/* Subprogramas*/
void lerVetor(int *dimlA, int *dimcA, int *nz, float Ax[D], int Ac[D], int Ap[D])
{
	/* Abrir o ficheiro DadosVetoresCRS.txt e lê-lo*/
	FILE *fdados;
	int i;
	
	fdados=fopen("DadosVetoresCRS.txt", "r");
	/* Se o programa não encontrar o ficheiro vai imprimir uma mensagem de erro*/
	if (fdados==NULL)
	{
	printf(" e impossivel abrir o ficheiro\n ");
	exit(EXIT_FAILURE);
	}
/*leitura de dados*/
	fscanf(fdados, "%d", dimlA);
	printf("\nO numero de linhas e: %d", *dimlA);
	
	fscanf(fdados, "%d", dimcA);
	printf("\nO numero de colunas e: %d", *dimcA);
	
	fscanf(fdados, "%d", nz);
	printf("\nA dimensao: %d", *nz);
	
	printf("\n");
	
	while(!feof(fdados))
	{
		for(i=0; i<*nz; i++) fscanf(fdados, "%f", &Ax[i]);
		for(i=0; i<*nz; i++) fscanf(fdados, "%d", &Ac[i]);
		for(i=0; i<(*dimlA)+1; i++) fscanf(fdados, "%d", &Ap[i]);
		}
	
	fclose(fdados);
}


void escreverVetor(int dimlA, int dimcA, int nz, float Ax[D], int Ac[D], int Ap[D])
{	
	/* O programa aqui vai proceder à impressão dos vetores*/
	int i;
	
	printf("\n o vetor Ax e:");
	for(i=0; i<nz; i++){
		printf(" %0.1f", Ax[i]);}
		printf("\n");
		
	printf("\n o vetor Ac e:");	
	for(i=0; i<nz; i++){
		printf(" %d", Ac[i]);}
		printf("\n");
	
	printf("\n o vetor Ap e:");	
	for(i=0; i < dimlA+1; i++){
		printf(" %d", Ap[i]);}
		printf("\n");	
}

void construirMatriz(int dimlA, int dimcA, int nz, float Ax[D], int Ac[D], int Ap[D], float A[L][C])
{ 
	/* O programa aqui vai proceder à construção da matriz densa*/
	int i, j, k;
	int a, b, c;
	
	for (i=0; i < dimlA; i++)
	{
		if(Ap[i]<Ap[i+1]){
			a=0;
			for(j=Ap[i];j < Ap[i+1]; j++)
			{
				for(c=a; c < Ac[j]; c++)
				{
					A[i][c]=0;
				}
				A[i][Ac[j]]=Ax[j];
				a=Ac[j]+1;
			}
			for(b=a; b < dimlA ;b++){
				A[i][b]=0;
			}
		}
		else{
			for(k=0; k< dimlA;k++){
				A[i][k]=0;}
		}
	}
}


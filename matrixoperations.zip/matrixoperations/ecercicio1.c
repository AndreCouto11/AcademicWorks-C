
/*Este programa tem como objetivo ler do ficheiro DadosMatrizDensa.txt 
 * o numero de linhas, o numero de colunas e os elementos de uma matriz A;
 * depois tem como objetivo obter os vetores pretendidos e escreve-los no ficheiro 
 * ResultadosVetoresAxAlAc.txt .
 * Este programa foi escrito por mim, André Abreu Couto, cujo número de estudante é 2019215056. */

#include <stdio.h>
#include <stdlib.h>

const int Max=100;

int main()
{
	FILE *fdados;
	
	fdados=fopen("DadosMatrizDensa.txt", "r"); /* Aqui o programa vai tentar abrir o ficheiro, caso nao consiga imprimirá uma mensagem de erro*/
	if (fdados==NULL)
	{
		printf("e impossivel abrir o ficheiro\n");
		exit (EXIT_FAILURE);
	}
	FILE *fvetores;
	
	fvetores=fopen("ResultadosVetoresAxAlAc.txt", "w"); /* Aqui o programa vai tentar abrir o ficheiro, caso nao consiga imprimirá uma mensagem de erro*/
	if (fvetores==NULL)
	{
		printf("e impossivel abrir o ficheiro\n");
		exit (EXIT_FAILURE);
	}
	/* declaração de variáveis*/
	int dimlA, dimcA;
	int v[Max], Ax[Max], Al[Max], Ac[Max];
	int i, k=0, dimv=0, ic, il;
	
	for (i=0; i<2; i++)   /* O programa agora vai ler os dois primeiros números do ficheiro DadosMatrizDensa */
	{
	fscanf(fdados, "%d", &v[i]);
	}
	dimlA=v[0];
	dimcA=v[1];
	
	printf( " O numero de linhas da matriz e: %d \n", dimlA);
	printf( " O numero de colunas da matriz e: %d \n", dimcA);
	
	/*vamos agora ler a matriz dos dois primeiros números até ao fim*/
	for (i=2; i < 83; i++) 
	{ fscanf(fdados, "%d", &v[i]);
		}
	/* O programa agora vai imprimir a matriz*/
	printf(" \n A matrix e a seguinte: \n");
	for (i=2; i < 83; i++)
	{
		printf("%d", v[i]);
		k++;
	/* O programa agora vai verificar quantos elementos são escritos,  e quando escrever os 9 elementos , muda de linha, reiniciando a variável*/
		if(k==9)
		{
			printf("\n");
			k=0;}
		}
		
		ic=0;
		il=0;
		for (i=2; i<83; i++)
		{ 
			if (v[i] != 0)
			{
				Ax[dimv] = v[i];
				Al[dimv] = il;
				Ac[dimv] = ic;
				dimv++;
			}
			ic++;
		if (ic==9)
		{
			ic=0;
			il++;
		}
	}
	/* O programa vai agora proceder à impressão dos vetores no ficheiro ResultadosVetoresAxAlAc*/
	fprintf(fvetores, " O vetor Ax e ");
		for (i=0; i<dimv; i++) { fprintf(fvetores, "%d", Ax[i]);
		}
		fprintf(fvetores, "\n");
	
	fprintf(fvetores, " O vetor Al e ");
		for (i=0; i<dimv; i++) { fprintf(fvetores, "%d", Al[i]);
		}
		fprintf(fvetores, "\n");
		
	fprintf(fvetores, " O vetor Ac e ");
		for (i=0; i<dimv; i++) { fprintf(fvetores, "%d", Ac[i]);
		}
	/*O programa vai agora fechas ambos os ficheiros*/
		fclose(fdados);
		fclose(fvetores);
	

	
	return 0;
}


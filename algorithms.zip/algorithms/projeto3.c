/*
 Este programa tem como objetivo obter uma ordenaçc˜ao
 * dos atletas que participaram em determinada maratona
 * tendo em conta o tempo ﬁnal de corrida.
 * André Abreu Couto, número de estudante: 2019215056
 */


#include <stdio.h>
#include <string.h>
#include <stdlib.h>


/* estrutura de dados que armazena o nome, sexo, ano de nascimento e o tempo final da corrida em minutos*/
struct RegistoAtleta{
	char nome[50];
	int ano;
	char sexo;
	int minutos;
	};

int Ordenar ( int dim, struct RegistoAtleta ListaAtletas[]);

	/* Programa principal*/
int main()
{
	printf( "Este programa vai imprimir a lista de atletas e o respetivo tempo obtidos numa maratona.\n");
	/* variável que guarda o numero de atletas*/
	int NrAtletas= 12;
	/* variável que permite guardar os dados dos atletas que participaram na maratona*/
	struct RegistoAtleta ListaAtletas[500]={
		{"Maria Silva", 1990, 'F', 50},
		{"Jose Alves", 2001, 'M', 48},
		{"Paulo Barros", 1998, 'M', 40},
		{"Claudia Matos",2000, 'F', 58},
		{"Ana Martins", 2002, 'F', 46},
		{"Carla Santos",1995, 'F', 49},
		{"Mario Moreira",2002, 'M', 60},
		{"Inacio Fernandes", 1999, 'M', 55},
		{"Catia Godinho", 1994, 'F', 44},
		{"Ivo Sapateiro", 1996, 'M', 52},
		{"Lucas Laranjeira", 2001, 'M', 41},
		{"Pedro Soares", 1997, 'M', 46} };
	/*inicialização de variáveis para criar as duas listas( feminina e masculina)*/
	int i=0, j=0;
	int m=0, f=0;
	/* construção da lista masculina copiando os dados dos atletas do sexo masculino para a nova lista "Masculino"*/
	struct RegistoAtleta Masculino[500];
	 for(i=0;i<NrAtletas;i++){
        if(ListaAtletas[i].sexo=='M'){
           
            strcpy(Masculino[j].nome,ListaAtletas[i].nome);/*A sintaxe strcpy copia o nome do atleta de uma string para a outra e será usada sempre que tiver que fazer este processo */
            Masculino[j].ano=ListaAtletas[i].ano;
            Masculino[j].minutos=ListaAtletas[i].minutos;
            Masculino[j].sexo=ListaAtletas[i].sexo;
            j++;
			m++;
			
        }
    }
    /* Reinicialização da variável para poder utilizar outra vez para construir a lista feminina*/
    j=0;
		/* construção da lista masculina copiando os dados dos atletas do sexo masculino para a nova lista "Feminino"*/
	struct RegistoAtleta Feminino[500];
	for(i=0;i<NrAtletas;i++){
        if(ListaAtletas[i].sexo=='F'){
            
            strcpy(Feminino[j].nome,ListaAtletas[i].nome);
            Feminino[j].ano=ListaAtletas[i].ano;
            Feminino[j].minutos=ListaAtletas[i].minutos;
            Feminino[j].sexo=ListaAtletas[i].sexo;
            j++;
			f++;
			
        }
	}
	/* Ordenar ambas as listas por ordem não decrescente*/
	Ordenar(m, Masculino);
	Ordenar(f, Feminino);
	
	 char c[2];
	 /* Processo de escolha da lista que o utilizador pretende imprimir*/
	 printf(" De que lista pretende obter os resultados ordenados(F ou M):");
	 scanf("%s",c);
	
     int d=0;
     if(strcmp(c,"M")==0){ /* a sintaxe strcmp(s1,s2) compara s1 com s2 e devolve 0 se forem iguais, caso isso aconteça imprimirá a lista masculina ordenada*/
        while(d<m){
            printf("%s %d min\n",Masculino[d].nome, Masculino[d].minutos);
            d++;
        }
    }
    else if(strcmp(c,"F")==0){/* a sintaxe strcmp(s1,s2) compara s1 com s2 e devolve 0 se forem iguais, caso isso aconteça imprimirá a lista feminina ordenada*/
       
        while(d<f){
            printf("%s %d min\n",Feminino[d].nome, Feminino[d].minutos);
            d++;
        }
    }
	
	return 0;
}
/* Função que ordena a lista em função do tempo através do método Bubble Sort*/
int Ordenar ( int dim, struct RegistoAtleta ListaAtletas[]){
	int a=0;
	int ordenado;
	struct RegistoAtleta aux;
	
	do{
		ordenado=1;
		for(a=0; a<dim-1; a++){ /* percorre o vetor e faz as trocas se não está ordenado*/
		if ( ListaAtletas[a].minutos >ListaAtletas[a+1].minutos){
			strcpy(aux.nome,ListaAtletas[a].nome);
			aux.ano = ListaAtletas[a].ano;
			aux.minutos = ListaAtletas[a].minutos;
			aux.sexo = ListaAtletas[a].sexo;
			strcpy(ListaAtletas[a].nome,ListaAtletas[a+1].nome);
			ListaAtletas[a].sexo = ListaAtletas[a+1].sexo;
			ListaAtletas[a].minutos = ListaAtletas[a+1].minutos;
			ListaAtletas[a].ano = ListaAtletas[a+1].ano;
			strcpy(ListaAtletas[a+1].nome,aux.nome);
			ListaAtletas[a+1].sexo =aux.sexo;
			ListaAtletas[a+1].minutos = aux.minutos;
			ListaAtletas[a+1].ano = aux.ano;
			ordenado = 0;
		}
	}
}
	while (!ordenado);/*repete até não haver mais trocas*/
	return 0;
}
			
	
	
	

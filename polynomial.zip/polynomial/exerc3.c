#include "polinomios.h"
#include "polinomios.c"
#include <stdio.h>

int main (){
	Polinomio p1,p2,p3;

	p1 = criar_polinomio();
	
	ler_polinomio (&p1);
	
	escrever_polinomio (p1);
	
	inserir_monomio(&p1);
	
	escrever_polinomio (p1);
	
	apagar(&p1);
	
	escrever_polinomio(p1);
		
	multiplicar_escalar(p1);
	
	escrever_polinomio (p1);
	
	p2=criar_polinomio();
	ler_polinomio (&p2);
	p3=somar(p1,p2);
	escrever_polinomio(p3);
		
	return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include "polinomios.h"

//criar, alocar e inicializar
Polinomio criar_polinomio(){ 
	int i;
	Polinomio p;
	//alocar
	p.ptcoefs = (float *)malloc(sizeof (float)*MAXDIM);
	
	if (p.ptcoefs == NULL){
		printf ("ERROR: NO MEMORY!!!");
		exit (1);
	}
	
	
	// Inicializar o grau do Polinomio
	p.grau = 0;
	
	
	//Inicializar o coeficiente do polinomio
	for (i = 0; i<MAXDIM; i++){
		p.ptcoefs[i] = 0.0;
	}
	return p;
}

void ler_polinomio (Polinomio *ptp){
	
	int i;
	
	printf ("Qual o grau do polinomio?");
	scanf("%d",&(ptp->grau));
	printf("\n");
	for (i = 0; i <= (ptp->grau); i++){
		printf ("Introduza o coeficiente do monomio de grau %d:", i);
		scanf ("%f", &(ptp->ptcoefs[i]));
	}
	printf("\n");
}

void escrever_polinomio (Polinomio p){
	int i;
	for (i = p.grau; i >1; i--){
		if( p.ptcoefs[i]!=0){
		printf ("%.2fx^%d + ", p.ptcoefs[i], i);
	}
}
	if( p.ptcoefs[1]!=0){
	printf ("%.2fx + ", p.ptcoefs[1]);}
	if( p.ptcoefs[0]!=0){
	printf ("%.2f", p.ptcoefs[0]);}
	printf("\n");
}

void inserir_monomio(Polinomio *p){
	
	int grau;
	float coef;
	
	printf("Indique o grau do monomio a inserir:");
	scanf("%d",&grau);
	printf("Indique o coeficiente do monomio a inserir:");
	scanf("%f",&coef);
	
	p->ptcoefs[grau]=p->ptcoefs[grau]+coef;
	
	int graumax;
	
	if (grau>p->grau){
		graumax=grau;}
	else{
		graumax = p->grau;}
		
		p->grau=graumax;
}

void apagar (Polinomio *p){

	int grau;
	
	printf("Indique o grau do monomio a apagar:");
	scanf("%d",&grau);
	
	p->ptcoefs[grau]=0;
}


Polinomio multiplicar_escalar (Polinomio p){
	
	int i;
	float escalar;
	Polinomio pn;
	printf("Indique o escalar pelo qual pretende multiplicar:");
	scanf("%f",&escalar);
	for(i=0;i<=p.grau;i++){
		p.ptcoefs[i]=p.ptcoefs[i]*escalar;}
	if (escalar==0){
		pn.grau=0;}
	else pn.grau=p.grau;
	return pn;
}

Polinomio somar(Polinomio P,Polinomio Q){
	int i,graumax;
	Polinomio PQ;
	PQ=criar_polinomio();
	
	if (P.grau>Q.grau){
		graumax=P.grau;}
	else{
		graumax = Q.grau;}
		
		PQ.grau=graumax;

	for(i=0;i<=PQ.grau;i++){ 
	PQ.ptcoefs[i]=Q.ptcoefs[i]+P.ptcoefs[i];
}	
return PQ;
}

	

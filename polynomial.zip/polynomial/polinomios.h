#ifndef POLINOMIOS
#define POLINOMIOS

#define MAXDIM 100 //dimensao maxima do polinomio

typedef struct polinomio {
	int grau; //grau do polinomio
	float * ptcoefs; //ponteiro para os coeficientes reais do polinomio (representacao dinamica)
}Polinomio;

//criar polinomio, alocar na memoria e inicializar
Polinomio criar_polinomio();

//ler polinomio
void ler_polinomio(Polinomio*);

//escrever polinomio
void escrever_polinomio(Polinomio);

//Inserir monómio
void inserir_monomio(Polinomio*);

//Apagar Monomio
void apagar (Polinomio*);

//Multiplicar Polinomio por um escalar
Polinomio multiplicar_escalar (Polinomio);

//somar polinomios
Polinomio somar(Polinomio,Polinomio);

#endif
